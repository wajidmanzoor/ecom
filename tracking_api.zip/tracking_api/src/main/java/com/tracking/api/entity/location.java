package com.tracking.api.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name="Location")
public class location {
	@Id
	private Integer id;
	@Column
	private double lat;
	@Column
	private double lon;
	@Column
	private Integer driverid;
	
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "create_date")
	private Date createDate;
	
	public location() {
		
	}
	
	public location(Integer id,double lat, double lon,  Integer driverid) {
		super();
		this.lat = lat;
		this.lon = lon;
		this.id = id;
		this.driverid = driverid;
	}
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public double getLat() {
		return lat;
	}

	public void setLat(double lat) {
		this.lat = lat;
	}

	public double getLon() {
		return lon;
	}

	public void setLon(double lon) {
		this.lon = lon;
	}

	public Integer getDriverid() {
		return driverid;
	}

	public void setDriverid(Integer driverid) {
		this.driverid = driverid;
	}

	@Override
	public String toString() {
		return "location [id=" + id + ", lat=" + lat + ", lon=" + lon + ", driverid=" + driverid + "]";
	}
	
	
	
	

}
