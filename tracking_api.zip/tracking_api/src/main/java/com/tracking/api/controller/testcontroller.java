package com.tracking.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tracking.api.doa.LocationDOA;
import com.tracking.api.entity.location;

@RestController

public class testcontroller {
	@Autowired
	LocationDOA locDoa;
	
	@GetMapping("/getloc/{driverid}")
	public List<location> getloc(@PathVariable Integer driverid) {
		
		return locDoa.getLocation(driverid);
		}
	@PostMapping("/sendloc")
	public String sendloc(@RequestBody location loc) {
		locDoa.sendLocation(loc);
		return "sent";
	}

}
