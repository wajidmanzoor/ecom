package com.tracking.api.doa;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tracking.api.entity.location;
import com.tracking.api.repo.LocationRepo;

@Service
public class LocationDOA {
	@Autowired
	LocationRepo locRepo;
	 public void sendLocation(location loc) {
		 locRepo.save(loc);
		 
	 }
	 
	 public List<location> getLocation(Integer driverid) {
		 return locRepo.findByDriveridOrderByCreateDateDesc(driverid);
			 }

}
