package com.tracking.api.repo;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tracking.api.entity.location;
@Repository
public interface LocationRepo extends JpaRepository<location, Integer>{
	public List<location> findByDriveridOrderByCreateDateDesc(Integer driverid);

}
