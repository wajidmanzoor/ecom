package com.deloitte.util;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
public class HibernateHelper {

	// Configuration
	// SessionFactory
	// Session
	// Transaction
	private static SessionFactory sessionfactory;
	
	public static SessionFactory getInstance() {
		if(sessionfactory == null) {
			sessionfactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		}
		
		return sessionfactory;
	}

}
