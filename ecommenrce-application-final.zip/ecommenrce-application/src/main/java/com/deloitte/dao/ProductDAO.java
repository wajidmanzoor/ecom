package com.deloitte.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.deloitte.entities.Product;
import com.deloitte.util.HibernateHelper;

public class ProductDAO {

	private Session session;
	
	public ProductDAO() {
		session = HibernateHelper.getInstance().openSession();
	}
	
	public int  saveProduct(Product product) {
		int prodId=0;
		try {	
			Transaction trans = session.beginTransaction();
			prodId = (int) session.save(product);
			trans.commit();
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		return prodId;
	}
	public List<Product> fetchProducts(){
		List<Product> prodList = new ArrayList<Product>();
		try {
		Query<Product> q = session.createQuery("from Product",Product.class);
		prodList=q.getResultList();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		return prodList;
		
		
	}
	
	public int listSize() {
		int size=0;
		List<Product> prodList = new ArrayList<Product>();
		try {
		Query<Product> q = session.createQuery("from Product",Product.class);
		prodList=q.getResultList();
		size=prodList.size();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		return size;
	}
	public List<Product> fetchProductsByCatId(int catid){
		List<Product> prodList = new ArrayList<Product>();
		try {
		Query<Product> q = session.createQuery("from Product as p where p.category.catId=:e",Product.class).setParameter("e", catid);
		prodList=q.getResultList();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		return prodList;
	}
	
}
