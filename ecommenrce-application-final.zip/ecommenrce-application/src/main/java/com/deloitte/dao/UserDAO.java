package com.deloitte.dao;

import org.hibernate.Session;

import com.deloitte.entities.User;
import com.deloitte.util.HibernateHelper;

public class UserDAO {

	public User getUserByEmailAndPassword(String email, String password) {
		
		User user = null;
		
		try (Session hibernateSession=HibernateHelper.getInstance().openSession();){
			String query = "from User where email =: e and password =: p";
			user = (User) hibernateSession.createQuery(query).setParameter("e", email)
							.setParameter("p",password).uniqueResult();
		
		}
		
		catch(Exception e) {
			e.printStackTrace();
			
		}
		/*finally {
			hibernateSession.close();*/
		
		return user;
		
		
	}
	

}
