package com.deloitte.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.deloitte.entities.Category;
import com.deloitte.util.HibernateHelper;

public class CategoryDAO {

	private Session session;
	
	public CategoryDAO() {
		session = HibernateHelper.getInstance().openSession();
	}
	
	public int  saveCategory(Category cat) {
		int catId=0;
		try {	
			Transaction trans = session.beginTransaction();
			catId = (int) session.save(cat);
			trans.commit();
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		return catId;
	}
	
	public List<Category> fetchCategories(){
		
		List<Category> catList = new ArrayList<Category>();
		try {
			Query<Category> query =session.createQuery("from Category",Category.class);
			catList = query.getResultList();
			
		} catch(Exception e) {
			
			e.printStackTrace();
			//System.out.println("problem");
		}finally {
			session.close();
		}
		
		return catList;
		
		
	}
	/**
	 * Used to fetch category object using category id.
	 * @param selectedCatId 
	 * @return category
	 */
	public Category fetchCategoryById(Integer selectedCatId) {
		Category category = null;
		try {
			category = session.get(Category.class, selectedCatId);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		return category;
	}
}
