package com.deloitte.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="PRODUCT")
public class Product {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="product_id", length=1000)
	private int productId;
	
	@Column(name="name", length=1000)
	private String productName;
	
	@Column(name="description")
	private String productDesc;
	
	@Column(name="price")
	private Integer productPrice;
	
	@Column(name="quantity")
	private Integer productQty;
	
	@Column(name="discount")
	private Integer productDiscount;
	@Column(name="image")
	private String productImage;
	@ManyToOne(cascade=CascadeType.ALL)
	private Category category;
	
	public Product() {
		
	}
	
	
	public Product(int productId, String productName, String productDesc, Integer productPrice, Integer productQty,
			Integer productDiscount, String productImage, Category category) {
		this.productId = productId;
		this.productName = productName;
		this.productDesc = productDesc;
		this.productPrice = productPrice;
		this.productQty = productQty;
		this.productDiscount = productDiscount;
		this.productImage = productImage;
		this.category = category;
	}
	
	public Product(String productName, String productDesc, Integer productPrice, Integer productQty,
			Integer productDiscount, String productImage, Category category) {
		this.productName = productName;
		this.productDesc = productDesc;
		this.productPrice = productPrice;
		this.productQty = productQty;
		this.productDiscount = productDiscount;
		this.productImage = productImage;
		this.category = category;
	}


	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public Integer getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Integer productPrice) {
		this.productPrice = productPrice;
	}
	public Integer getProductQty() {
		return productQty;
	}
	public void setProductQty(Integer productQty) {
		this.productQty = productQty;
	}
	public Integer getProductDiscount() {
		return productDiscount;
	}
	public void setProductDiscount(Integer productDiscount) {
		this.productDiscount = productDiscount;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	
	public int getDiscountedPrice() {
		return (int) (this.productPrice*(1-this.productDiscount/100.0));
	}
	
	
	
	
}
