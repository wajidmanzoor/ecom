package com.deloitte.servlets;

         
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.deloitte.dao.UserDAO;
import com.deloitte.entities.User;
//import org.apache.coyote.http11.Http11AprProtocol;



public class LoginServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
	 
	protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws IOException {
		// get data
		HttpSession session = req.getSession();
		PrintWriter out = resp.getWriter();

		String  email = req.getParameter("email");
		String password = req.getParameter("password");
		//System.out.println("email: "+email);
		//System.out.println("password: "+password);
		if(email.isBlank() || password.isBlank()) {
			System.out.println("Invalid credintials");
			return;
		}
		
		// check if in database
		UserDAO userDao = new UserDAO();
		User user =userDao.getUserByEmailAndPassword(email,password);
		try {
		if(user==null) {
			session.setAttribute("warning",
					"Invalid Details Re Enter Credentials");
				resp.sendRedirect("login.jsp");
			}
				
			
		else {
			session.setAttribute("current-user", user);
			if ("admin".equals(user.getRole())){
				resp.sendRedirect("admin.jsp");
			}
			else if ("enduser".equals(user.getRole())) {
				resp.sendRedirect("homepage.jsp");
			
			}
			else {
				out.println("role not defined contact admin");
			}
		}
		}
		catch(Exception e) {
			e.printStackTrace();
			session.setAttribute("warning",
					"Login Unseccessfull.");
			resp.sendRedirect("login.jsp");
				
		}
		finally {
			System.out.println("Finally block executed.");
			out.close();
		}
		
		
		
	}
}


