package com.deloitte.servlets;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.deloitte.dao.CategoryDAO;
import com.deloitte.dao.ProductDAO;
import com.deloitte.entities.Category;
import com.deloitte.entities.Product;

/**
 * Servlet implementation class AdminServlet
 */
@MultipartConfig
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession httpsession = request.getSession();
		String operation =request.getParameter("operation");
		if(operation.equals("addCategory")) {
			String catTitle = request.getParameter("catTitle");
			String catDescription = request.getParameter("catDescription");
			
			Category category = new Category();
			category.setTitle(catTitle);
			category.setDescription(catDescription);
			CategoryDAO cDao = new CategoryDAO();
			int catId = cDao.saveCategory(category);
			if(catId >0) {
				httpsession.setAttribute("success","Category "+catTitle+" saved succesfully with id: " +catId);
			}
			else {
				httpsession.setAttribute("warning", "failed to save");
			}
			response.sendRedirect("admin.jsp");
			
		}
		else if(operation.equals("addProduct")) {
			String productName = request.getParameter("productName");
			String productDesc = request.getParameter("productDescription");
			Integer productPrice = Integer.parseInt(request.getParameter("productPrice"));
			Integer productQty = Integer.parseInt(request.getParameter("productQuantity"));
			Integer productDiscount = Integer.parseInt(request.getParameter("productDiscount"));
			
			Integer selectedCatId = Integer.parseInt(request.getParameter("catId"));
			
			Part part = request.getPart("productImage");
			String fileName = part.getSubmittedFileName();
			String filePath = request.getServletContext().getRealPath("imgs")
							+File.separator+"Product"+File.separator+fileName;
			System.out.println(filePath);
			try(InputStream inputStream = part.getInputStream();FileOutputStream fos = new FileOutputStream(filePath)){
				
				byte[] bytes= new byte[inputStream.available()];
				inputStream.read(bytes);
				fos.write(bytes);
				/*
				 * byte[] bytes = new byte(inputStream.available());
				 * inputstream.read(bytes)
				 *   */
				
				
			}catch(Exception e) {
				e.printStackTrace();
				
			}
			
			
			
			CategoryDAO cDao = new CategoryDAO();
			
			Category category = cDao.fetchCategoryById(selectedCatId);
			
			Product product = new Product(productName, productDesc, productPrice, productQty,
					productDiscount, fileName, category);
			
			ProductDAO pDao = new ProductDAO();
			int prodId = pDao.saveProduct(product);
			
			if(prodId >0) {
				httpsession.setAttribute("success","Product "+productName+" saved succesfully with id: " +prodId);
			}
			else {
				httpsession.setAttribute("warning", "failed to save");
			}
			response.sendRedirect("admin.jsp");
			
		}
	}

}
