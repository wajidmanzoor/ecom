package com.deloitte.servlets;



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.deloitte.entities.User;
import com.deloitte.util.HibernateHelper;

public class RegistrationServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = -964607756692427924L;

	protected void doPost(HttpServletRequest req,HttpServletResponse res ) throws IOException {
		
		// get session object from HTML request
		HttpSession session = req.getSession();
		// Get parameters from HTML request.
		String userName = req.getParameter("userName");
		String emailId = req.getParameter("emailId");
		String password = req.getParameter("password");
		String phone = req.getParameter("phone");
		String address = req.getParameter("address");

		
		PrintWriter out;
		try {
			out = res.getWriter();
			// Server side validation
			if(userName.isBlank()) {
				out.println("<h1>Name is Blank</h1>");
				return;
			}
			//create POJO instance
			User user = new User(userName,emailId,password,phone,"default.png",address,"enduser");
			
			
			// Create session to connect to database
			Session hibernateSession = HibernateHelper.getInstance().openSession();
			Transaction tran = hibernateSession.beginTransaction();
			// save user in database
			int uId = (int) hibernateSession.save(user);
			tran.commit();
			hibernateSession.close();
			
			session.setAttribute("success","User Sucessfully Registered with Id: "+uId);
			res.sendRedirect("login.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			session.setAttribute("warning","Invalid shit ");
			res.sendRedirect("register.jsp");

		}
		
		
		
		
		
		
	}
	

}
